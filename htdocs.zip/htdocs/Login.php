<!DOCTYPE html>
<html>
<head>
	<title></title>
	 <?php

                    include_once('config.php');
                    ?>
</head>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<body>
  <form method="post" action="index.php">
                    <h2>Login</h2>
                  
                       <i class="material-icons">person</i>
                          <input type="text" name="username" id="i1" class="input" placeholder="Nome de usuário"/><br><br>

                           <i class="material-icons">vpn_key</i>
                    <input type="password" name="password" id="i2" class="input" placeholder="Senha"/><Br><br>
                                        <input type="submit" id="i3" placeholder="Enviar"/>

                        
                    </form>
</body>
</html>