<?php
$databaseHost = 'localhost';
$databaseName = 'tcc';
$databaseUsername = 'PayPizza';
$databasePassword = 'paypizza';
$mysqli = mysqli_connect($databaseHost,
$databaseUsername,$databasePassword,$databaseName);

$con = $mysqli;


?>
