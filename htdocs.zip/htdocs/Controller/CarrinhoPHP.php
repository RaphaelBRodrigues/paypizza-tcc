<?php
session_start();
include_once('config.php');
//PIZZA NORMAL
/*$__SESSION['$total'] = $__SESSION['$total'] + $_SESSION['P1'] = $_POST['in1'];
$__SESSION['$total'] = $__SESSION['$total'] + $_SESSION['P2'] = $_POST['in2'];
$__SESSION['$total'] = $__SESSION['$total'] + $_SESSION['P3'] = $_POST['in3'];
$__SESSION['$total'] = $__SESSION['$total'] + $_SESSION['P4'] = $_POST['in4'];
$__SESSION['$total'] = $__SESSION['$total'] + $_SESSION['P5'] = $_POST['in5'];
$__SESSION['$total'] = $__SESSION['$total'] + $_SESSION['P6'] = $_POST['in6'];
$__SESSION['$total'] = $__SESSION['$total'] + $_SESSION['P7'] = $_POST['in7'];
$__SESSION['$total'] = $__SESSION['$total'] + $_SESSION['P8'] = $_POST['in8'];
$__SESSION['$total'] = $__SESSION['$total'] + $_SESSION['P9'] = $_POST['in9'];
$__SESSION['$total'] = $__SESSION['$total'] + $_SESSION['P10'] = $_POST['in10'];
$__SESSION['$total'] = $__SESSION['$total'] + $_SESSION['P11'] = $_POST['in11'];
$__SESSION['$total'] = $__SESSION['$total'] + $_SESSION['P12'] = $_POST['in12'];
*/
echo $__SESSION['$total'];
?>
