# TCC
TCC Do ensino médio integrado com t.i(UNASP 2019) desenvolvido pelos Alunos Raphael Barbosa Rodrigues e Lucas Gabriel Mofardini de Almeida,o projeto consiste em um sistema web para comércios

Link:Paypizza.epizy.com
HOST:ftpupload.net
USERNAME:epiz_23520784
